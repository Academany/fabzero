#define F_CPU 1000000UL
#include <avr/io.h>
#include <util/delay.h>

int main (void)
{
        
 DDRA = 0b00001000; // set PB2 as output in DDRB

 while(1) {
          // set PB2 high to turn led on
          PORTB = 0b00001000;
          _delay_ms(1000);
          // set PB2 low to turn led off 
          PORTB = 0b00000000;
          _delay_ms(1000);
          }
}
